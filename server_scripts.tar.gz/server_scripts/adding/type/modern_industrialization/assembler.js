ServerEvents.recipes(event => {

// Сірчана броня
  event.recipes.modern_industrialization.assembler(32, 200)
  .itemIn("6x modern_industrialization:rubber_sheet")
  .itemIn("6x modern_industrialization:stainless_steel_plate")
  .itemIn("2x minecraft:glass")
  .itemIn("1x modern_industrialization:rubber_helmet")
  .itemOut("1x roll_mod:hazmat_helmet")
    
event.recipes.modern_industrialization.assembler(32, 200)
  .itemIn("8x modern_industrialization:stainless_steel_rod")
  .itemIn("6x modern_industrialization:stainless_steel_plate")
  .itemIn("6x modern_industrialization:rubber_sheet")
  .itemOut("1x roll_mod:hazmat_chestplate")
    
  event.recipes.modern_industrialization.assembler(32, 200)
  .itemIn("8x modern_industrialization:stainless_steel_rod")
  .itemIn("6x modern_industrialization:stainless_steel_plate")
  .itemIn("4x modern_industrialization:rubber_sheet")
  .itemIn("1x minecraft:white_wool")
  .itemOut("1x roll_mod:hazmat_leggings")
    
  event.recipes.modern_industrialization.assembler(32, 200)
  .itemIn("6x modern_industrialization:rubber_sheet")
  .itemIn("4x modern_industrialization:stainless_steel_plate")
  .itemIn("2x modern_industrialization:lead_plate")
  .itemIn("1x modern_industrialization:rubber_boots")
  .itemOut("1x roll_mod:hazmat_boots")

  event.recipes.modern_industrialization.assembler(64, 200)
  .itemIn("16x modern_industrialization:platinum_wire")
  .itemIn("16x modern_industrialization:polytetrafluoroethylene_plate")
  .itemIn("8x modern_industrialization:advanced_pump")
  .itemIn("4x modern_industrialization:advanced_motor")
  .itemIn("4x modern_industrialization:digital_circuit")
  .itemIn("1x modern_industrialization:chemical_reactor")
  .itemOut("1x mi_tweaks:large_chemical_reactor")

event.recipes.modern_industrialization.assembler(32, 200)
  .itemIn("1x modern_industrialization:diode")
  .itemIn("4x modern_industrialization:resistor")
  .itemIn("4x modern_industrialization:transistor")
  .fluidIn("modern_industrialization:polytetrafluoroethylene", 150)
  .itemOut("1x modern_industrialization:op_amp")

event.recipes.modern_industrialization.assembler(16, 200)
  .itemIn("3x modern_industrialization:rubber_sheet")
  .itemIn("2x modern_industrialization:advanced_motor")
  .itemIn("1x modern_industrialization:annealed_copper_cable")
  .itemOut("1x roll_mod:advanced_conveyor")

event.recipes.modern_industrialization.assembler(16, 200)
  .itemIn("3x modern_industrialization:annealed_copper_cable")
  .itemIn("2x modern_industrialization:advanced_motor")
  .itemIn("1x roll_mod:advanced_piston")
  .itemIn("1x modern_industrialization:digital_circuit")
  .itemIn("2x modern_industrialization:stainless_steel_rod")
  .itemOut("1x roll_mod:advanced_robot_arm")

event.recipes.modern_industrialization.assembler(16, 200)
  .itemIn("3x modern_industrialization:stainless_steel_plate")
  .itemIn("2x modern_industrialization:annealed_copper_cable")
  .itemIn("2x modern_industrialization:stainless_steel_rod")
  .itemIn("1x modern_industrialization:stainless_steel_gear")
  .itemIn("1x modern_industrialization:advanced_motor")
  .itemOut("1x roll_mod:advanced_piston")

event.recipes.modern_industrialization.assembler(16, 800)
  .itemIn("8x modern_industrialization:magnalium_plate")
  .itemIn("4x modern_industrialization:magnalium_gear")
  .itemIn("4x modern_industrialization:fluid_pipe")
  .itemIn("3x modern_industrialization:large_motor")
  .itemIn("1x modern_industrialization:magnalium_ring")
  .itemOut("1x roll_mod:magnalium_engine")

  event.recipes.modern_industrialization.assembler(16, 800)
  .itemIn("16x modern_industrialization:magnalium_rod")
  .itemIn("6x modern_industrialization:magnalium_gear")
  .itemIn("2x modern_industrialization:magnalium_large_plate")
  .itemOut("1x roll_mod:transmission")

    event.recipes.modern_industrialization.assembler(16, 800)
  .itemIn("20x roll_mod:treated_plate")
  .itemIn("8x roll_mod:treated_planks")
  .itemIn("8x modern_industrialization:magnalium_rod")
  .itemIn("1x roll_mod:magnalium_engine")
  .itemIn("1x roll_mod:transmission")
  .itemOut("1x immersive_aircraft:biplane")

  event.recipes.modern_industrialization.assembler(16, 800)
  .itemIn("64x minecraft:bamboo")
  .itemIn("4x modern_industrialization:magnalium_rod")
  .itemIn("4x modern_industrialization:motor")
  .itemIn("2x modern_industrialization:electronic_circuit")
  .itemIn("1x roll_mod:magnalium_engine")
  .itemOut("1x immersive_aircraft:quadrocopter")

  event.recipes.modern_industrialization.assembler(32, 1600)
  .itemIn("64x minecraft:bamboo_planks")
  .itemIn("16x modern_industrialization:magnalium_rod")
  .itemIn("16x modern_industrialization:magnalium_large_plate")
  .itemIn("16x modern_industrialization:motor")
  .itemIn("4x modern_industrialization:electronic_circuit")
  .itemIn("3x roll_mod:magnalium_engine")
  .itemIn("3x modern_industrialization:aluminum_rotor")
  .itemOut("1x immersive_aircraft:bamboo_hopper")

  event.recipes.modern_industrialization.assembler(16, 200)
  .itemIn("16x roll_mod:treated_plate")
  .itemIn("8x immersive_aircraft:sail")
  .itemIn("8x modern_industrialization:magnalium_rod")
  .itemIn("4x minecraft:chest")
  .itemIn("2x modern_industrialization:large_motor")
  .itemIn("1x roll_mod:magnalium_engine")
  .itemOut("1x immersive_aircraft:cargo_airship")

  event.recipes.modern_industrialization.assembler(16, 200)
  .itemIn("12x roll_mod:carbon_fiber")
  .itemIn("4x minecraft:paper")
  .fluidIn("modern_industrialization:glue", 1500)
  .itemOut("1x roll_mod:carbon_mesh")

    event.recipes.modern_industrialization.assembler(32, 200)
  .itemIn("4x modern_industrialization:analog_circuit")
  .itemIn("4x modern_industrialization:iron_plate")
  .itemIn("2x roll_mod:sulfur_berry")
  .itemIn("1x roll_mod:redstone_battery")
  .itemIn("1x extended_industrialization:silver_tesla_top_load")
  .itemOut("1x roll_mod:lv_storm_scanner")

    event.recipes.modern_industrialization.assembler(32, 200)
  .itemIn("32x modern_industrialization:redstone_alloy_dust")
  .itemIn("16x modern_industrialization:battery_alloy_plate")
  .itemIn("2x modern_industrialization:analog_circuit")
  .itemOut("1x roll_mod:redstone_battery")

  event.recipes.modern_industrialization.assembler(256, 1600)
  .itemIn("1x roll_mod:sulfur_jam")
  .itemIn("1x farmersdelight:rice_roll_medley_block")
  .itemIn("1x roll_mod:purple_wafer")
  .itemIn("1x stellaris:moon_fruit")
  .itemIn("1x sophisticatedbackpacks:upgrade_base")
  .itemIn("1x tide:midas_fish")
  .itemIn("1x minecraft:enchanted_golden_apple")
  .itemIn("1x fruitsdelight:mangosteen_cake")
  .itemIn("1x moredelight:chicken_sandwich_with_egg_and_tomato")
  .itemOut("1x sophisticatedbackpacks:advanced_feeding_upgrade")


//космос space

// Броня
  event.recipes.modern_industrialization.assembler(16, 200)
  .itemIn("2x modern_industrialization:stainless_steel_rod")// Фіксатори, кільця для з'єднання
  .itemIn("1x #c:plates/aluminum")                          // Шари теплового захисту – з лавсану (Mylar), каптону та алюмінієвих фольг
  .itemIn("5x roll_mod:carbon_mesh")                       // Мікрометеоритний шар – кевлароподібна тканина
  .itemIn("1x modern_industrialization:analog_circuit")     // Простенькі аналогові контролери, радіо, клапани, тощо
  .itemIn("1x modern_industrialization:silicon_battery")
  .itemIn("1x ae2:quartz_glass")                            // Шолом і візор – виготовлений із полікарбонату та покритий золотом для відбиття сонячного випромінювання
  .fluidIn("modern_industrialization:nylon", 600)           // Герметичний шар – виготовлений із нейлону
  .itemOut("1x stellaris:space_suit_helmet")

  event.recipes.modern_industrialization.assembler(16, 200)
  .itemIn("4x modern_industrialization:stainless_steel_rod")// Фіксатори, кільця для з'єднання
  .itemIn("2x #c:plates/aluminum")                          // Шари теплового захисту – з лавсану (Mylar), каптону та алюмінієвих фольг
  .itemIn("8x roll_mod:carbon_mesh")                       // Мікрометеоритний шар – кевлароподібна тканина
  .itemIn("2x modern_industrialization:advanced_pump")                        // Система життєзабезпечення
  .itemIn("16x modern_industrialization:fluid_pipe")                        // Система життєзабезпечення
  .fluidIn("modern_industrialization:nylon", 1200)          // Герметичний шар – виготовлений із нейлону
  .itemOut("1x stellaris:space_suit_chestplate")

  event.recipes.modern_industrialization.assembler(16, 200)
  .itemIn("2x modern_industrialization:stainless_steel_rod")// Фіксатори, кільця для з'єднання
  .itemIn("2x #c:plates/aluminum")                          // Шари теплового захисту – з лавсану (Mylar), каптону та алюмінієвих фольг
  .itemIn("7x roll_mod:carbon_mesh")                       // Мікрометеоритний шар – кевлароподібна тканина
  .itemIn("4x minecraft:white_wool")                            // з начосом
  .fluidIn("modern_industrialization:nylon", 600)           // Герметичний шар – виготовлений із нейлону
  .itemOut("1x stellaris:space_suit_leggings")

  event.recipes.modern_industrialization.assembler(16, 200)
  .itemIn("2x modern_industrialization:stainless_steel_rod")// Фіксатори, кільця для з'єднання
  .itemIn("2x #c:plates/aluminum")                          // Шари теплового захисту – з лавсану (Mylar), каптону та алюмінієвих фольг
  .itemIn("4x roll_mod:carbon_mesh")                       // Мікрометеоритний шар – кевлароподібна тканина
  .itemIn("6x roll_mod:rubber_ingot")       // Товста підошва для захисту від гострих уламків
  .fluidIn("modern_industrialization:nylon", 600)           // Герметичний шар – виготовлений із нейлону
  .itemOut("1x stellaris:space_suit_boots")

// Ракети
  event.recipes.modern_industrialization.assembler(16, 200)
  .itemIn("4x modern_industrialization:space_alloy_large_plate")
  .itemIn("8x modern_industrialization:netherite_plate")
  .itemIn("2x roll_mod:carbon_mesh")
  .itemIn("3x modern_industrialization:turbo_machine_hull")
  .itemIn("4x modern_industrialization:digital_circuit")
  .itemIn("3x modern_industrialization:stainless_steel_gear")
  .itemOut("1x roll_mod:nose_mk1")

  event.recipes.modern_industrialization.assembler(16, 200)
  .itemIn("8x modern_industrialization:space_alloy_large_plate")
  .itemIn("16x modern_industrialization:stainless_steel_bolt")
  .itemIn("4x modern_industrialization:digital_circuit")
  .itemIn("32x modern_industrialization:fluid_pipe")
  .itemOut("1x roll_mod:tank_mk1")

  event.recipes.modern_industrialization.assembler(16, 200)
  .itemIn("4x modern_industrialization:space_alloy_large_plate")
  .itemIn("4x modern_industrialization:netherite_plate")
  .itemIn("1x modern_industrialization:digital_circuit")
  .itemIn("4x modern_industrialization:advanced_pump")
  .itemIn("2x modern_industrialization:advanced_motor")
  .itemIn("32x modern_industrialization:fluid_pipe")
  .itemIn("4x modern_industrialization:stainless_steel_rotor")
  .itemOut("1x roll_mod:engine_mk1")

  event.recipes.modern_industrialization.assembler(16, 200)
  .itemIn("8x modern_industrialization:stainless_steel_gear")
  .itemIn("4x modern_industrialization:space_alloy_plate")
  .itemIn("4x modern_industrialization:netherite_plate")
  .itemIn("8x modern_industrialization:space_alloy_curved_plate")
  .itemOut("1x roll_mod:fin_mk1")

  event.recipes.modern_industrialization.assembler(16, 200)
  .itemIn("1x modern_industrialization:turbo_machine_hull")
  .itemIn("4x modern_industrialization:digital_circuit")
  .itemIn("8x modern_industrialization:space_alloy_large_plate")
  .itemIn("4x modern_industrialization:stainless_steel_rotor")
  .itemIn("4x modern_industrialization:advanced_motor")
  .itemIn("4x modern_industrialization:advanced_pump")
  .itemIn("32x modern_industrialization:fluid_pipe")
  .itemOut("1x modern_industrialization:space_alloy_machine_casing_pipe")

//ae 2 applied energystics ЛЕГЕНДА!
  event.recipes.modern_industrialization.assembler(16, 200)
  .itemIn("4x ae2:fluix_glass_cable")
  .itemIn("2x #minecraft:wool")
  .itemIn("1x modern_industrialization:rubber_sheet")
  .itemOut("4x ae2:fluix_covered_cable")

    event.recipes.modern_industrialization.assembler(16, 200)
  .itemIn("4x ae2:fluix_glass_cable")
  .itemIn("2x #minecraft:wool")
  .fluidIn("modern_industrialization:styrene_butadiene_rubber", 4)
  .itemOut("4x ae2:fluix_covered_cable")

  event.recipes.modern_industrialization.assembler(16, 200)
  .itemIn("1x ae2:fluix_block")
  .itemIn("64x modern_industrialization:copper_fine_wire")
  .itemIn("8x modern_industrialization:steel_rod")
  .itemIn("1x ae2:charged_certus_quartz_crystal")
  .itemIn("4x modern_industrialization:iron_plate")
  .itemOut("1x ae2:crystal_resonance_generator")

  event.recipes.modern_industrialization.assembler(8, 200)
  .itemIn("3x modern_industrialization:stainless_steel_plate")
  .itemIn("1x ae2:calculation_processor")
  .itemIn("3x modern_industrialization:aluminum_wire")
  .fluidIn("modern_industrialization:polyethylene", 350)
  .itemOut("1x ae2:advanced_card")

    event.recipes.modern_industrialization.assembler(8, 200)
  .itemIn("3x modern_industrialization:stainless_steel_plate")
  .itemIn("1x ae2:calculation_processor")
  .itemIn("3x modern_industrialization:gold_wire")
  .fluidIn("modern_industrialization:polyethylene", 250)
  .itemOut("1x ae2:basic_card")
  
  event.recipes.modern_industrialization.assembler(8, 200)
  .itemIn("3x modern_industrialization:stainless_steel_plate")
  .itemIn("4x ae2:fluix_pearl")
  .itemIn("3x modern_industrialization:copper_fine_wire")
  .fluidIn("modern_industrialization:polyethylene", 350)
  .itemOut("1x ae2:wireless_booster")

  event.recipes.modern_industrialization.assembler(8, 400)
  .itemIn("1x modern_industrialization:silicon_plate")
  .itemIn("4x #ae2:all_certus_quartz")
  .itemIn("1x ae2:logic_processor")
  .fluidIn("modern_industrialization:molten_redstone", 200)
  .itemOut("1x ae2:cell_component_1k")

  event.recipes.modern_industrialization.assembler(8, 400)
  .itemIn("2x modern_industrialization:gold_fine_wire")
  .itemIn("4x ae2:cell_component_1k")
  .itemIn("1x ae2:calculation_processor")
  .fluidIn("modern_industrialization:molten_redstone", 100)
  .itemOut("1x ae2:cell_component_4k")

  event.recipes.modern_industrialization.assembler(8, 200)
  .itemIn("4x modern_industrialization:aluminum_plate")
  .itemIn("4x ae2:quartz_glass")
  .itemIn("3x ae2:logic_processor")
  .fluidIn("modern_industrialization:polyethylene", 250)
  .itemOut("1x ae2:blank_pattern")

  event.recipes.modern_industrialization.assembler(8, 200)
  .itemIn("4x modern_industrialization:stainless_steel_plate")
  .itemIn("4x ae2:quartz_glass")
  .itemIn("3x ae2:logic_processor")
  .fluidIn("modern_industrialization:polytetrafluoroethylene", 250)
  .itemOut("4x ae2:blank_pattern")

  event.recipes.modern_industrialization.assembler(32, 200)
  .itemIn("4x ae2:engineering_processor")
  .itemIn("1x ae2:blank_pattern")
  .itemOut("1x extendedae:pattern_modifier")

  event.recipes.modern_industrialization.assembler(16, 20)
  .itemIn("1x ae2:fluix_covered_cable")
  .itemIn("1x ae2:logic_processor")
  .itemOut("1x ae2:fluix_smart_cable")


  event.recipes.modern_industrialization.assembler(8, 200)
  .itemIn("6x modern_industrialization:stainless_steel_plate")
  .itemIn("4x modern_industrialization:turbo_upgrade")
  .itemIn("4x ae2:fluix_pearl")
  .itemIn("1x ae2:fluix_block")
  .fluidIn("modern_industrialization:polyvinyl_chloride", 250)
  .itemOut("1x ae2:growth_accelerator")

    event.recipes.modern_industrialization.assembler(32, 100)
  .itemIn("4x ae2:certus_quartz_crystal")
  .itemIn("2x modern_industrialization:electronic_circuit")
  .itemIn("2x ae2:logic_processor")
  .fluidIn("modern_industrialization:polyethylene", 250)
  .itemOut("4x ae2:formation_core")

    event.recipes.modern_industrialization.assembler(32, 100)
  .itemIn("4x minecraft:quartz")
  .itemIn("2x modern_industrialization:electronic_circuit")
  .itemIn("2x ae2:logic_processor")
  .fluidIn("modern_industrialization:polyethylene", 250)
  .itemOut("4x ae2:annihilation_core")

    event.recipes.modern_industrialization.assembler(32, 200)
  .itemIn("12x modern_industrialization:stainless_steel_plate")
  .itemIn("6x ae2:quartz_vibrant_glass")
  .itemIn("4x modern_industrialization:robot_arm")
  .itemIn("4x ae2:engineering_processor")
  .itemIn("2x ae2:formation_core")
  .itemIn("2x ae2:annihilation_core")
  .itemIn("1x modern_industrialization:assembler")
  .itemOut("1x ae2:molecular_assembler")

event.recipes.modern_industrialization.assembler(64, 200)
  .itemIn("24x modern_industrialization:niobium_titanium_alloy_rod")
  .itemIn("12x extendedae:concurrent_processor")
  .itemIn("4x ae2:molecular_assembler")
  .itemIn("4x modern_industrialization:turbo_upgrade")
  .itemIn("4x modern_industrialization:processing_unit")
  .itemOut("1x extendedae:ex_molecular_assembler")

event.recipes.modern_industrialization.assembler(32, 200)
  .itemIn("9x ae2:fluix_crystal")
  .itemIn("4x ae2:engineering_processor")
  .itemIn("2x ae2:formation_core")
  .itemIn("1x ae2:fluix_smart_cable")
  .itemOut("1x ae2:formation_plane")

event.recipes.modern_industrialization.assembler(32, 200)
  .itemIn("9x ae2:fluix_crystal")
  .itemIn("4x ae2:engineering_processor")
  .itemIn("2x ae2:annihilation_core")
  .itemIn("1x ae2:fluix_smart_cable")
  .itemOut("1x ae2:annihilation_plane")

event.recipes.modern_industrialization.assembler(32, 200)
  .itemIn("4x ae2:fluix_pearl")
  .itemIn("1x ae2:formation_plane")
  .itemIn("1x ae2:engineering_processor")
  .itemOut("1x ae2:me_p2p_tunnel")

event.recipes.modern_industrialization.assembler(32, 200)
  .itemIn("16x modern_industrialization:palladium_fine_wire")
  .itemIn("4x extendedae:concurrent_processor")
  .itemIn("1x modern_industrialization:highly_advanced_machine_hull")
  .itemOut("1x extendedae:machine_frame")

event.recipes.modern_industrialization.assembler(32, 200)
  .itemIn("4x modern_industrialization:turbo_upgrade")
  .itemIn("4x extendedae:concurrent_processor")
  .itemIn("1x extendedae:machine_frame")
  .itemIn("1x ae2:io_port")
  .itemOut("1x extendedae:ex_io_port")

event.recipes.modern_industrialization.assembler(32, 200)
.itemIn("8x ae2:engineering_processor")
.itemIn("4x extendedae:concurrent_processor")
.itemIn("2x ae2:drive")
.itemIn("1x extendedae:machine_frame")
.itemOut("1x extendedae:ex_drive")

event.recipes.modern_industrialization.assembler(32, 200)
.itemIn("16x modern_industrialization:palladium_fine_wire")
.itemIn("4x extendedae:concurrent_processor")
.itemIn("1x extendedae:ingredient_buffer")
.itemIn("1x #extendedae:extended_interface")
.itemIn("1x extendedae:machine_frame")
.itemOut("1x extendedae:oversize_interface")

  event.recipes.modern_industrialization.assembler(64, 100)
  .itemIn("12x modern_industrialization:chrome_vanadium_steel_bolt")
  .itemIn("4x modern_industrialization:chrome_vanadium_steel_plate")
  .itemIn("4x modern_industrialization:iridium_plate")
  .itemIn("2x extendedae:concurrent_processor")
  .itemIn("1x ae2:engineering_processor")
  .fluidIn("modern_industrialization:epoxy", 250)
  .itemOut("1x extendedae:assembler_matrix_wall")
  
event.recipes.modern_industrialization.assembler(64, 200)
.itemIn("64x modern_industrialization:palladium_rod")
.itemIn("16x extendedae:concurrent_processor")
.itemIn("16x ae2:blue_smart_dense_cable")
.itemIn("1x modern_industrialization:chrome_vanadium_steel_bolt")
.itemIn("1x extendedae:assembler_matrix_wall")
.itemOut("1x extendedae:assembler_matrix_frame")

event.recipes.modern_industrialization.assembler(64, 200)
.itemIn("6x ae2:blue_lumen_paint_ball")
.itemIn("4x modern_industrialization:processing_unit")
.itemIn("4x extendedae:concurrent_processor")
.itemIn("4x ae2:engineering_processor")
.itemIn("2x extendedae:ex_pattern_provider")
.itemIn("1x extendedae:assembler_matrix_wall")
.itemOut("1x extendedae:assembler_matrix_pattern")


event.recipes.modern_industrialization.assembler(8, 100)
.itemIn("8x modern_industrialization:redstone_alloy_fine_wire")
.itemIn("4x ae2:fluix_crystal")
.itemIn("2x ae2:quartz_fiber")
.itemOut("1x ae2:fluix_glass_cable")

event.recipes.modern_industrialization.assembler(16, 1600)
.itemIn("8x modern_industrialization:stainless_steel_rod")
.itemIn("4x ae2:quartz_block")
.itemIn("2x roll_mod:advanced_robot_arm")
.itemIn("1x modern_industrialization:hv_energy_input_hatch")
.itemOut("1x extendedae:crystal_fixer")

event.recipes.modern_industrialization.assembler(16, 100)
.itemIn("6x modern_industrialization:aluminum_plate")
.itemIn("4x ae2:quartz_glass")
.itemIn("1x modern_industrialization:electronic_circuit")
.fluidIn("250x modern_industrialization:polyethylene")
.itemOut("1x ae2:item_cell_housing")

event.recipes.modern_industrialization.assembler(32, 100)
.itemIn("6x modern_industrialization:aluminum_plate")
.itemIn("4x ae2:quartz_glass")
.itemIn("1x modern_industrialization:electronic_circuit")
.fluidIn("250x modern_industrialization:polytetrafluoroethylene")
.itemOut("4x ae2:item_cell_housing")

event.recipes.modern_industrialization.assembler(16, 100)
.itemIn("6x modern_industrialization:annealed_copper_plate")
.itemIn("4x ae2:quartz_glass")
.itemIn("1x modern_industrialization:electronic_circuit")
.fluidIn("250x modern_industrialization:polyethylene")
.itemOut("1x ae2:fluid_cell_housing")

event.recipes.modern_industrialization.assembler(32, 100)
.itemIn("6x modern_industrialization:annealed_copper_plate")
.itemIn("4x ae2:quartz_glass")
.itemIn("1x modern_industrialization:electronic_circuit")
.fluidIn("250x modern_industrialization:polytetrafluoroethylene")
.itemOut("4x ae2:fluid_cell_housing")
  
  //все інше... Нудно..

    event.recipes.modern_industrialization.assembler(8, 400)
  .itemIn("12x roll_mod:carbon_fiber")
  .itemIn("2x modern_industrialization:emerald_plate")
  .fluidIn("100x modern_industrialization:epoxy")
  .itemOut("1x roll_mod:fr4_sheet")


      event.recipes.modern_industrialization.assembler(32, 400)
  .itemIn("16x modern_industrialization:tungsten_cable")
  .itemIn("6x roll_mod:lapotron_lens")
  .itemIn("6x roll_mod:mirror")
  .itemIn("4x roll_mod:lapotron_laser")
  .itemIn("2x modern_industrialization:processing_unit")
  .itemIn("1x modern_industrialization:titanium_64_machine_casing")
  .fluidIn("600x modern_industrialization:polyvinyl_chloride")
  .itemOut("1x roll_mod:lapotronic_laser_block")

    event.recipes.modern_industrialization.assembler(8, 400)
  .itemIn("4x modern_industrialization:iridium_curved_plate")
  .itemIn("3x roll_mod:mirror")
  .itemIn("1x roll_mod:lapotron_large_crystal")
  .itemIn("1x roll_mod:emitter")
  .itemOut("1x roll_mod:lapotron_laser")

event.recipes.modern_industrialization.assembler(32, 100)
.itemIn("4x modern_industrialization:palladium_plate")
.itemIn("4x modern_industrialization:emerald_plate")
.itemIn("2x modern_industrialization:processing_unit")
.itemIn("1x roll_mod:nether_star_ring")
.itemOut("1x roll_mod:emitter")

  event.recipes.modern_industrialization.assembler(128, 200)
  .itemIn("6x modern_industrialization:titanium_large_plate")
  .itemIn("4x modern_industrialization:processing_unit")
  .itemIn("4x roll_mod:advanced_robot_arm")
  .itemIn("1x modern_industrialization:highly_advanced_machine_hull")
  .itemIn("1x modern_industrialization:circuit_assembler")
  .fluidIn("modern_industrialization:polyvinyl_chloride", 1000)
  .itemOut("1x modern_industrialization:photolithographer")

event.recipes.modern_industrialization.assembler(32, 100)
.itemIn("3x minecraft:stone")
.fluidIn("minecraft:lava", 10)
.itemOut("4x railcraft:stone_tie")

event.recipes.modern_industrialization.assembler(32, 100)
.itemIn("2x modern_industrialization:electrum_cable")
.itemIn("2x modern_industrialization:electronic_circuit")
.itemIn("1x roll_mod:energium_large_dirty_crystal")
.itemOut("1x roll_mod:energium_battery")

event.recipes.modern_industrialization.assembler(32, 400)
.itemIn("32x modern_industrialization:stainless_steel_rod_magnetic")
.itemIn("16x modern_industrialization:titanium_curved_plate")
.itemIn("4x modern_industrialization:digital_circuit")
.itemIn("2x roll_mod:lapotron_large_crystal")
.itemOut("1x roll_mod:gravi_engine_mk_1")

event.recipes.modern_industrialization.assembler(32, 1600)
.itemIn("32x modern_industrialization:titanium_plate")
.itemIn("8x modern_industrialization:blastproof_alloy_plate")
.itemIn("8x modern_industrialization:netherite_plate")
.itemIn("4x roll_mod:gravi_engine_mk_1")
.itemIn("1x roll_mod:lapotron_battery_t1")
.itemIn("1x roll_mod:lapotron_battery_t1")
.itemOut("1x roll_mod:multi_protecting_gravi_chestplate")

event.recipes.modern_industrialization.assembler(32, 100)
.itemIn("4x ae2:quartz_glass")
.itemIn("2x modern_industrialization:tungsten_wire")
.fluidIn("50x modern_industrialization:mercury")
.itemOut("1x roll_mod:quartz_lamp")  

event.recipes.modern_industrialization.assembler(32, 100)
.itemIn("1x roll_mod:nether_star_plate")
.itemOut("1x roll_mod:nether_star_ring")  
.itemOut("1x roll_mod:nether_star_dust")  

event.recipes.modern_industrialization.assembler(32, 100)
.itemIn("2x extendedae:machine_frame")
.itemIn("8x ae2:quantum_ring")
.itemIn("2x ae2:quantum_link")
.itemIn("12x modern_industrialization:niobium_titanium_alloy_plate")
.itemIn("4x ae2:wireless_booster")
.itemIn("2x extendedae:concurrent_processor")
.fluidIn("500x modern_industrialization:cryofluid")
.itemOut("2x extendedae:wireless_connect") 

event.recipes.modern_industrialization.assembler(64, 200)
.itemIn("6x ae2:red_lumen_paint_ball")
.itemIn("4x modern_industrialization:processing_unit")
.itemIn("4x extendedae:concurrent_processor")
.itemIn("2x modern_industrialization:highly_advanced_upgrade")
.itemIn("1x extendedae:assembler_matrix_wall")
.itemOut("1x extendedae:assembler_matrix_speed")

event.recipes.modern_industrialization.assembler(64, 200)
.itemIn("6x ae2:purple_lumen_paint_ball")
.itemIn("4x ae2:logic_processor")
.itemIn("2x extendedae:concurrent_processor")
.itemIn("2x roll_mod:advanced_robot_arm")
.itemIn("1x extendedae:ex_molecular_assembler")
.itemIn("1x extendedae:assembler_matrix_wall")
.itemOut("1x extendedae:assembler_matrix_crafter")

event.recipes.modern_industrialization.assembler(32, 100)
.itemIn("64x roll_mod:advanced_piston")
.itemIn("64x roll_mod:advanced_piston")
.itemIn("1x modern_industrialization:electric_compressor")
.itemIn("1x ae2:interface")
.itemOut("1x ae2:condenser")

event.recipes.modern_industrialization.assembler(32, 100)
.itemIn("4x modern_industrialization:palladium_plate")
.itemIn("3x modern_industrialization:digital_circuit")
.itemIn("1x roll_mod:lv_storm_scanner")
.itemIn("1x roll_mod:energium_battery")
.itemOut("1x roll_mod:hv_storm_scanner")
.itemOut("4x modern_industrialization:analog_circuit")
.itemOut("4x modern_industrialization:iron_plate")

event.recipes.modern_industrialization.assembler(32, 100)
.itemIn("8x modern_industrialization:steel_plate")
.itemIn("8x modern_industrialization:motor")
.itemIn("3x modern_industrialization:steel_block")
.itemIn("3x modern_industrialization:analog_circuit")
.itemIn("1x roll_mod:redstone_battery")
.itemOut("1x roll_mod:lv_mining_drill")

event.recipes.modern_industrialization.assembler(32, 100)
.itemIn("6x modern_industrialization:aluminum_large_plate")
.itemIn("6x modern_industrialization:electrum_plate")
.itemIn("3x modern_industrialization:motor")
.itemIn("1x roll_mod:redstone_battery")
.itemIn("1x roll_mod:lv_mining_drill")
.itemOut("1x roll_mod:advanced_lv_mining_drill")

event.recipes.modern_industrialization.assembler(32, 200)
.itemIn("8x modern_industrialization:large_motor")
.itemIn("8x modern_industrialization:emerald_plate")
.itemIn("8x modern_industrialization:diamond_plate")
.itemIn("3x modern_industrialization:aluminum_block")
.itemIn("3x modern_industrialization:electronic_circuit")
.itemIn("1x roll_mod:energium_battery")
.itemOut("1x roll_mod:mv_mining_drill")

event.recipes.modern_industrialization.assembler(32, 200)
.itemIn("6x modern_industrialization:netherite_large_plate")
.itemIn("6x modern_industrialization:stainless_steel_plate")
.itemIn("3x modern_industrialization:large_motor")
.itemIn("1x roll_mod:energium_battery")
.itemIn("1x roll_mod:mv_mining_drill")
.itemOut("1x roll_mod:advanced_mv_mining_drill")
//hv
event.recipes.modern_industrialization.assembler(32, 200)
.itemIn("8x modern_industrialization:advanced_motor")
.itemIn("16x modern_industrialization:iridium_plate")
.itemIn("3x modern_industrialization:stainless_steel_block")
.itemIn("3x modern_industrialization:digital_circuit")
.itemIn("1x roll_mod:lapotron_battery_t1")
.itemOut("1x roll_mod:hv_mining_drill")

event.recipes.modern_industrialization.assembler(32, 200)
.itemIn("6x modern_industrialization:rhodium_plated_palladium_plate")
.itemIn("6x modern_industrialization:chrome_vanadium_steel_plate")
.itemIn("3x modern_industrialization:advanced_motor")
.itemIn("1x roll_mod:lapotron_battery_t1")
.itemIn("1x roll_mod:hv_mining_drill")
.itemOut("1x roll_mod:advanced_hv_mining_drill")
//ev
event.recipes.modern_industrialization.assembler(32, 200)
.itemIn("8x modern_industrialization:large_advanced_motor")
.itemIn("8x modern_industrialization:osmiridium_plate")
.itemIn("8x modern_industrialization:niobium_titanium_alloy_plate")
.itemIn("3x modern_industrialization:titanium_block")
.itemIn("3x modern_industrialization:processing_unit")
.itemIn("1x roll_mod:lapotron_battery_t2")
.itemOut("1x roll_mod:ev_mining_drill")

event.recipes.modern_industrialization.assembler(32, 200)
.itemIn("6x modern_industrialization:rhodium_plated_palladium_plate")
.itemIn("6x modern_industrialization:chrome_vanadium_steel_plate")
.itemIn("3x modern_industrialization:large_advanced_motor")
.itemIn("1x roll_mod:lapotron_battery_t2")
.itemIn("1x roll_mod:ev_mining_drill")
.itemOut("1x roll_mod:advanced_ev_mining_drill")

event.recipes.modern_industrialization.assembler(16, 100)
.itemIn("1x minecraft:glass")
.itemIn("1x modern_industrialization:redstone_alloy_rod")
.itemIn("1x modern_industrialization:electrum_plate")
.itemIn("1x modern_industrialization:steel_rod")
.itemIn("2x modern_industrialization:redstone_alloy_bolt")
.itemIn("1x roll_mod:treated_plate")
.itemOut("2x roll_mod:redstone_tube");

event.recipes.modern_industrialization.assembler(16, 540)
.itemIn("6x roll_mod:meteorite_metal_ingot")
.itemIn("4x minecraft:netherite_ingot")
.itemIn("2x modern_industrialization:electronic_circuit")
.itemIn("1x roll_mod:amethyst_oscillator")
.itemIn("1x roll_mod:energium_battery")
.itemOut("1x roll_mod:meteorite_metal_nano_saber");

event.recipes.modern_industrialization.assembler(32, 200)
.itemIn("32x modern_industrialization:stainless_steel_blade")
.itemIn("8x modern_industrialization:polytetrafluoroethylene_plate")
.itemIn("4x roll_mod:standard_chip_pmic")
.itemIn("2x modern_industrialization:electronic_circuit")
.itemIn("1x roll_mod:amethyst_oscillator")
.itemIn("1x roll_mod:energium_battery")
.itemOut("1x roll_mod:mv_electric_saber");

event.recipes.modern_industrialization.assembler(32, 200)
.itemIn("32x modern_industrialization:chrome_vanadium_steel_blade")
.itemIn("8x modern_industrialization:polytetrafluoroethylene_plate")
.itemIn("8x roll_mod:standard_chip_pmic")
.itemIn("2x modern_industrialization:digital_circuit")
.itemIn("1x roll_mod:amethyst_oscillator")
.itemIn("1x roll_mod:lapotron_battery_t1")
.itemOut("1x roll_mod:hv_electric_saber");

event.recipes.modern_industrialization.assembler(32, 200)
.itemIn("32x modern_industrialization:osmiridium_curved_plate")
.itemIn("16x roll_mod:standard_chip_pmic")
.itemIn("8x modern_industrialization:ruthenium_plate")
.itemIn("4x modern_industrialization:cooling_cell")
.itemIn("2x modern_industrialization:processing_unit")
.itemIn("1x roll_mod:amethyst_oscillator")
.itemIn("1x roll_mod:lapotron_battery_t2")
.itemOut("1x roll_mod:ev_electric_saber");


event.recipes.modern_industrialization.assembler(32, 100)
.itemIn("16x modern_industrialization:silicon_p_doped_plate")
.itemIn("16x modern_industrialization:silicon_n_doped_plate")
.itemIn("6x modern_industrialization:aluminum_plate")
.itemIn("4x roll_mod:mirror")
.itemIn("2x modern_industrialization:digital_circuit")
.itemIn("1x roll_mod:energium_large_dirty_crystal")
.itemOut("1x roll_mod:energium_laser");


event.recipes.modern_industrialization.assembler(32, 10000)
.itemIn("8x immersive_aircraft:sail")
.itemIn("8x immersive_aircraft:sail")
.itemIn("8x immersive_aircraft:sail")
.itemIn("8x immersive_aircraft:enhanced_propeller")
.itemIn("2x roll_mod:magnalium_engine")
.itemIn("64x roll_mod:treated_plate")
.itemIn("4x immersive_aircraft:improved_landing_gear")
.itemIn("2x sophisticatedstorage:gold_chest")
.itemIn("8x modern_industrialization:large_motor")
.itemOut("1x immersive_aircraft:warship");


event.recipes.modern_industrialization.assembler(16, 100)
.itemIn("4x modern_industrialization:steel_rod")
.itemIn("4x roll_mod:treated_plate")
.itemIn("4x immersive_aircraft:sail")
.itemIn("2x immersive_aircraft:improved_landing_gear")
.itemIn("1x immersive_aircraft:enhanced_propeller")
.itemIn("1x modern_industrialization:lv_diesel_generator")
.itemOut("1x immersive_aircraft:airship");

event.recipes.modern_industrialization.assembler(16, 100)
.itemIn("8x modern_industrialization:copper_plate")
.itemIn("2x immersive_aircraft:propeller")
.itemOut("1x immersive_aircraft:enhanced_propeller");


event.recipes.modern_industrialization.assembler(32, 200)
.itemIn("8x modern_industrialization:incoloy_large_plate")
.itemIn("4x modern_industrialization:large_advanced_motor")
.itemIn("1x modern_industrialization:incoloy_machine_casing_pipe")
//.itemIn("1x roll_mod:research_high_efficiency_steam_turbine", 0.0 ) //todo: add this when research is 
.itemOut("1x modern_industrialization:high_efficiency_steam_turbine");


event.recipes.modern_industrialization.assembler(32, 100)
.itemIn("20x modern_industrialization:analog_circuit")
.itemIn("16x minecraft:glass")
.itemIn("16x modern_industrialization:steel_rod")
.itemIn("4x modern_industrialization:diamond_plate")
.itemIn("4x modern_industrialization:steel_large_plate")
.itemIn("1x modern_industrialization:basic_machine_hull")
.itemOut("1x roll_mod:research_workbench"); 

event.recipes.modern_industrialization.assembler(32, 100)
.itemIn("8x modern_industrialization:aluminum_plate")
.itemIn("4x modern_industrialization:electronic_circuit")
.itemIn("4x modern_industrialization:silicon_wafer")
.itemIn("2x roll_mod:red_lens")
.itemIn("2x roll_mod:green_lens")
.itemIn("2x roll_mod:light_blue_lens")
.itemOut("1x createcybernetics:basecyberware_cybereyes"); 

event.recipes.modern_industrialization.assembler(512, 100)
.itemIn("16x modern_industrialization:tantalum_fine_wire")
.itemIn("16x modern_industrialization:rhodium_fine_wire")
.itemIn("8x roll_mod:carbon_mesh")
.itemIn("4x modern_industrialization:iridium_plate")
.itemIn("4x roll_mod:nether_star_plate")
.fluidIn("250x modern_industrialization:epoxy")
.registeredCondition({
          "mi_tweaks:voltage": {
            "voltage": "ev"
          }})
.itemOut("1x roll_mod:iridium_based_board"); 


event.recipes.modern_industrialization.assembler(512, 100)
.itemIn("64x modern_industrialization:rhodium_fine_wire")
.itemIn("8x roll_mod:smd_capacitor")
.itemIn("8x roll_mod:standard_chip_pmic")
.itemIn("4x roll_mod:smd_diode")
.itemIn("2x roll_mod:emitter")
.itemIn("2x roll_mod:sensor")
.itemIn("1x roll_mod:iridium_based_board")
.fluidIn("250x modern_industrialization:epoxy")
.registeredCondition({
          "mi_tweaks:voltage": {
            "voltage": "ev"
          }})
.itemOut("1x roll_mod:iridium_based_board_assembly"); 





})