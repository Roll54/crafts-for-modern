ServerEvents.recipes(event => {

      event.shaped(
    Item.of('silentgear:crude_repair_kit', 1),[
      ' A ',
      'B B',
      'BBB',
    ],{
      A: 'modern_industrialization:iron_rod',
      B: '#minecraft:logs',
})
    
      event.shaped(
    Item.of('silentgear:sturdy_repair_kit', 1),[
      ' A ',
      'B B',
      'BBB',
    ],{
      A: 'modern_industrialization:steel_rod',
      B: 'modern_industrialization:iron_plate',
})  
    
       event.shaped(
    Item.of('silentgear:crimson_repair_kit', 1),[
      ' A ',
      'B B',
      'BBB',
    ],{
      A: 'modern_industrialization:aluminum_rod',
      B: 'silentgear:crimson_steel_ingot',
})

       event.shaped(
    Item.of('silentgear:azure_repair_kit', 1),[
      ' A ',
      'B B',
      'BBB',
    ],{
      A: 'modern_industrialization:titanium_rod',
      B: 'silentgear:azure_electrum_ingot',
})

  event.shaped(
    Item.of('modern_industrialization:pyrolyse_oven', 1),[
      'CAC',
      'DBD',
      'CAC',
    ],{
      A: 'modern_industrialization:large_pump',
      C: 'modern_industrialization:invar_large_plate',
      D: 'modern_industrialization:cupronickel_wire_magnetic',
      B: 'modern_industrialization:coke_oven',
  })
    
  event.shaped(
    Item.of('modern_industrialization:chemically_inert_ptfe_casing', 1),[
      'ABA',
      'BCB',
      'ABA',
    ],{
      A: 'modern_industrialization:polytetrafluoroethylene_rod',
      B: 'modern_industrialization:polytetrafluoroethylene_large_plate',
      C: 'modern_industrialization:polytetrafluoroethylene_gear',
  })
    
  event.shaped(
    Item.of('modern_industrialization:polytetrafluoroethylene_machine_casing_pipe', 1),[
      'ABA',
      'ACA',
      'AAA',
    ],{
      A: 'modern_industrialization:platinum_plate',
      B: 'modern_industrialization:polytetrafluoroethylene_gear',
      C: 'modern_industrialization:chemically_inert_ptfe_casing',
  })

  event.shaped(
    Item.of('roll_mod:advanced_conveyor', 1),[
      'SSS',
      'WAW',
      'SSS',
    ],{
      W: 'modern_industrialization:advanced_motor',
      S: 'modern_industrialization:rubber_sheet',
      A: 'modern_industrialization:annealed_copper_cable',
  })

  event.shaped(
    Item.of('roll_mod:advanced_robot_arm', 1),[
      'WWW',
      'ARA',
      'PCR',
    ],{
      A: 'modern_industrialization:advanced_motor',
      C: 'modern_industrialization:digital_circuit',
      P: 'roll_mod:advanced_piston',
      R: 'modern_industrialization:stainless_steel_rod',
      W: 'modern_industrialization:annealed_copper_cable',
  })

  event.shaped(
    Item.of('roll_mod:advanced_piston', 1),[
      'PPP',
      'WBB',
      'WAG',
    ],{
      A: 'modern_industrialization:advanced_motor',
      B: 'modern_industrialization:stainless_steel_rod',
      G: 'modern_industrialization:stainless_steel_gear',
      P: 'modern_industrialization:stainless_steel_plate',
      W: 'modern_industrialization:annealed_copper_cable',
  })

    event.shaped(
    Item.of('immersive_aircraft:gyrodyne', 1),[
      'ABA',
      'CDC',
      'FFF',
    ],{
      A: 'immersive_aircraft:sail',
      B: 'modern_industrialization:bronze_rotor',
      C: 'modern_industrialization:bronze_gear',
      D: 'modern_industrialization:bronze_rod',
      F: 'roll_mod:treated_planks',
  })

  event.shaped(
    Item.of('stellaris:rocket_station', 1),[
      'AAA',
      'BCD',
      'EFG', 
    ],{
      A: 'roll_mod:advanced_robot_arm',
      B: '#ae2:illuminated_panel',
      C: 'modern_industrialization:configurable_chest',
      D: 'modern_industrialization:advanced_motor',
      E: 'modern_industrialization:turbo_machine_hull',
      F: 'modern_industrialization:assembler',
      G: 'modern_industrialization:annealed_copper_block',
  })

  event.shaped(
    Item.of('ae2:controller', 1),[
      'ABA',
      'BCB',
      'ABA',
    ],{
      A: 'ae2:fluix_crystal',
      B: 'modern_industrialization:analog_circuit',
      C: 'modern_industrialization:basic_machine_hull',
  })

    event.shaped(
    Item.of('travelanchors:travel_anchor', 1),[
      'AAA',
      'ABA',
      'AAA',
    ],{
      A: 'modern_industrialization:black_steel_ingot',
      B: 'minecraft:ender_pearl',
  })

    event.shaped(
    Item.of('travelanchors:travel_staff', 1),[
      ' BC',
      ' AB',
      'A  ',
    ],{
      A: 'modern_industrialization:black_steel_ingot',
      B: 'modern_industrialization:enderium_ingot',
      C: 'minecraft:ender_eye',
  })

    event.shaped(
    Item.of('modern_industrialization:circuit_assembler', 1),[
      ' A ',
      'BCB',
      'DAD',
    ],{
      A: 'modern_industrialization:digital_circuit',
      B: 'roll_mod:advanced_robot_arm',
      C: 'modern_industrialization:assembler',
      D: 'modern_industrialization:advanced_motor',
  })

  event.shaped(
    Item.of('toms_storage:storage_terminal'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        B: 'modern_industrialization:bronze_gear',
        D: 'minecraft:chiseled_bookshelf',
        C: 'minecraft:waxed_copper_bulb',
        A: 'roll_mod:treated_plate'
    }
)

  event.shaped(
    Item.of('toms_storage:crafting_terminal'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        B: 'minecraft:crafter',
        A: 'roll_mod:treated_plate',
        D: 'toms_storage:storage_terminal',
        C: 'modern_industrialization:steel_gear'
    }
)
  event.shaped(
    Item.of('toms_storage:inventory_connector'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        B: 'modern_industrialization:bronze_gear',
        C: 'minecraft:hopper',
        D: 'minecraft:chest',
        A: 'roll_mod:treated_plate'
    }
)

event.shaped(
    Item.of('toms_storage:open_crate'),
    [
        'ABA',
        'CBC',
        'DBD'
    ],
    {
        D: 'modern_industrialization:bronze_gear',
        B: 'minecraft:hopper',
        A: 'roll_mod:treated_plate',
        C: 'roll_mod:treated_log'
    }
)

  event.shaped(
    Item.of('toms_storage:trim', 4),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        C: 'modern_industrialization:bronze_gear',
        D: 'minecraft:chest',
        A: 'roll_mod:treated_log',
        B: 'roll_mod:treated_plate'
    }
)

  event.shaped(
    Item.of('toms_storage:inventory_cable', 3),
    [
        'ABA',
        'CCC',
        'ABA'
    ],
    {
        B: 'modern_industrialization:bronze_gear',
        C: 'modern_industrialization:item_pipe',
        A: 'roll_mod:treated_plate'
    }
)

event.shaped(
    Item.of('toms_storage:inventory_interface'),
    [
        'ABA',
        'CCC',
        'ADA'
    ],
    {
        A: 'roll_mod:treated_planks',
        C: 'minecraft:comparator',
        D: 'minecraft:hopper',
        B: 'minecraft:chest'
    }
)

  event.shaped(
    Item.of('toms_storage:inventory_cable_connector'),
    [
        ' A',
        'BC',
        ' A'
    ],
    {
        A: 'modern_industrialization:bronze_gear',
        C: 'toms_storage:inventory_connector',
        B: 'toms_storage:inventory_cable'
    }
)

  event.shaped(
    Item.of('toms_storage:inventory_proxy'),
    [
        'AAA',
        'BCB',
        'AAA'
    ],
    {
        A: 'roll_mod:treated_planks',
        B: 'minecraft:dropper',
        C: 'minecraft:repeater'
    }
)



event.shaped(
    Item.of('modern_industrialization:thermal_centrefuge'),
    [
        'ABA',
        'CDC',
        'EFE'
    ],
    {
        E: 'modern_industrialization:large_motor',
        A: 'modern_industrialization:steel_rod_magnetic',
        B: 'modern_industrialization:aluminum_tank',
        C: 'modern_industrialization:cupronickel_coil',
        D: 'modern_industrialization:centrifuge',
        F: 'modern_industrialization:large_pump'
    }
)

event.shaped(
    Item.of('modern_industrialization:lv_ore_washer'),
    [
        'ABA',
        'CDC',
        'EEE'
    ],
    {
        E: 'modern_industrialization:large_motor',
        B: 'modern_industrialization:aluminum_tank',
        A: 'modern_industrialization:aluminum_rotor',
        D: 'modern_industrialization:chemical_reactor',
        C: 'modern_industrialization:large_pump'
    }
)

event.shaped(
    Item.of('ae2:io_port'),
    [
        'ABA',
        'CDC',
        'EFE'
    ],
    {
        C: 'ae2:drive',
        F: 'ae2:logic_processor',
        E: 'modern_industrialization:aluminum_plate',
        A: 'ae2:export_bus',
        B: 'ae2:cell_component_4k',
        D: 'ae2:fluix_smart_cable'
    }
)

event.shaped(
    Item.of('ae2:drive'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        D: 'minecraft:chiseled_bookshelf',
        B: 'ae2:engineering_processor',
        A: 'modern_industrialization:aluminum_plate',
        C: 'ae2:fluix_smart_cable'
    }
)
event.shaped(
    Item.of('ae2:pattern_provider'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        D: 'minecraft:crafting_table',
        B: 'ae2:logic_processor',
        C: 'modern_industrialization:electrum_plate',
        A: 'modern_industrialization:aluminum_plate'
    }
)

event.shaped(
    Item.of('ae2:crafting_unit'),
    [
        'ABA',
        'C C',
        'ABA'
    ],
    {
        B: 'ae2:calculation_processor',
        C: 'modern_industrialization:electronic_circuit',
        A: 'modern_industrialization:aluminum_large_plate'
    }
)

event.shaped(
    Item.of('ae2:chest'),
    [
        'ABA',
        'C C',
        'DDD'
    ],
    {
        B: 'ae2:terminal',
        D: 'modern_industrialization:aluminum_plate',
        A: 'ae2:quartz_glass',
        C: 'ae2:fluix_smart_cable'
    }
)

event.shaped(
    Item.of('ae2:memory_card'),
    [
        'ABC',
        'DDD'
    ],
    {
        B: 'ae2:calculation_processor',
        C: 'modern_industrialization:aluminum_plate',
        D: 'modern_industrialization:gold_wire',
        A: 'ae2:cell_component_1k'
    }
)

event.shaped(
    Item.of('ae2netanalyser:network_analyser'),
    [
        'A A',
        'BCB',
        '   '
    ],
    {
        B: 'modern_industrialization:lead_plate',
        A: 'modern_industrialization:gold_rod',
        C: 'minecraft:redstone_lamp'
    }
)

event.shaped(
    Item.of('ae2:energy_cell'),
    [
        'ABA',
        'BCB',
        'ABA'
    ],
    {
        C: 'ae2:calculation_processor',
        B: 'ae2:fluix_block',
        A: 'modern_industrialization:aluminum_plate'
    }
)

event.shaped(
    Item.of('railcraft:steam_locomotive'),
    [
        ' AA',
        'BBC',
        'D D'
    ],
    {
        C: 'modern_industrialization:steel_boiler',
        B: 'modern_industrialization:steel_machine_casing',
        D: 'minecraft:minecart',
        A: 'modern_industrialization:steel_tank'
    }
)

event.shaped(
    Item.of('railcraft:electric_locomotive'),
    [
        'AB ',
        'CDE',
        'FGF'
    ],
    {
        B: 'modern_industrialization:analog_circuit',
        D: 'roll_mod:redstone_battery',
        F: 'modern_industrialization:motor',
        E: 'modern_industrialization:mv_lv_transformer',
        C: 'modern_industrialization:basic_machine_hull',
        G: 'minecraft:minecart',
        A: 'minecraft:redstone_lamp'
    }
)

event.shaped(
    Item.of('ae2:meteorite_compass'),
    [
        ' A ',
        'BCB',
        ' B '
    ],
    {
        C: 'roll_mod:raw_magnetite',
        B: 'modern_industrialization:iron_plate',
        A: 'ae2:charged_certus_quartz_crystal'
    }
)

event.shaped(
    Item.of('stellaris:rocket_launch_pad'),
    [
        'AAA',
        'BBB'
    ],
    {
        A: 'modern_industrialization:netherite_plate',
        B: 'extended_industrialization:steel_plated_bricks'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:tank_upgrade'),
    [
        'A',
        'B',
        'A'
    ],
    {
        B: 'sophisticatedbackpacks:upgrade_base',
        A: 'modern_industrialization:steel_tank'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:feeding_upgrade'),
    [
        ' A ',
        'BCB',
        'DED'
    ],
    {
        B: 'roll_mod:advanced_robot_arm',
        A: 'roll_mod:golden_baton',
        C: 'sophisticatedbackpacks:upgrade_base',
        D: 'minecraft:enchanted_golden_apple',
        E: 'minecraft:cake'
    }
)

event.shaped(
    Item.of('ae2:wireless_receiver'),
    [
        'A B',
        'AC ',
        'DAA'
    ],
    {
        D: 'modern_industrialization:digital_circuit',
        A: 'modern_industrialization:stainless_steel_plate',
        C: 'modern_industrialization:stainless_steel_rod',
        B: 'roll_mod:quantum_star'
    }
)

event.shaped(
    Item.of('ae2:wireless_access_point'),
    [
        'ABA',
        'ACA'
    ],
    {
        A: 'modern_industrialization:stainless_steel_ring',
        C: 'ae2:fluix_smart_dense_cable',
        B: 'ae2:wireless_receiver'
    }
)
event.shaped(
    Item.of('modern_industrialization:titanium_64_machine_casing'),
    [
        'AAA',
        'ABA',
        'AAA'
    ],
    {
        A: 'modern_industrialization:titanium_64_plate',
        B: 'modern_industrialization:titanium_gear'
    }
)

event.shaped(
    Item.of('extendedae:caner'),
    [
        'ABC',
        'D D',
        'CEA'
    ],
    {
        A: 'ae2:annihilation_core',
        C: 'ae2:formation_core',
        E: 'extendedae:machine_frame',
        B: 'extended_industrialization:electric_canning_machine',
        D: 'modern_industrialization:stainless_steel_rod'
    }
)

event.shaped(
    Item.of('extendedae:ex_import_bus_part'),
    [
        ' AB',
        'C  ',
        ' AB'
    ],
    {
        A: 'ae2:speed_card',
        B: 'roll_mod:advanced_robot_arm',
        C: 'ae2:import_bus'
    }
)

event.shaped(
    Item.of('extendedae:ex_export_bus_part'),
    [
        ' AB',
        'C  ',
        ' AB'
    ],
    {
        A: 'ae2:speed_card',
        B: 'roll_mod:advanced_robot_arm',
        C: 'ae2:export_bus'
    }
)

event.shaped(
    Item.of('extendedae:wireless_tool'),
    [
        'ABA',
        ' C ',
    ],
    {
        C: 'ae2:network_tool',
        B: 'ae2:cell_component_1k',
        A: 'ae2:wireless_receiver'
    }
)


event.shaped(
    Item.of('tide:fishing_line'),
    [
        ' AA',
        ' A ',
        'AA '
    ],
    {
        A: 'minecraft:string'
    }
)

event.shaped(
    Item.of('ae2:cell_workbench'),
    [
        'ABA',
        'CDC',
        'CEC'
    ],
    {
        E: 'minecraft:crafting_table',
        D: 'extendedae:ex_interface',
        B: 'ae2:item_cell_housing',
        A: 'modern_industrialization:robot_arm',
        C: 'modern_industrialization:aluminum_plate'
    }
)

event.shaped(
    Item.of('roll_mod:prospector_pickaxe'),
    [
        'AB',
        'C ',
        'C '
    ],
    {
        B: 'minecraft:iron_nugget',
        A: 'minecraft:iron_ingot',
        C: 'minecraft:stick'
    }
)

event.shaped(
    Item.of('railcraft:powered_rolling_machine'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        B: 'modern_industrialization:motor',
        C: 'modern_industrialization:piston',
        D: 'modern_industrialization:electric_compressor',
        A: 'modern_industrialization:steel_gear'
    }
)

event.shaped(
    Item.of('roll_mod:redstone_tube'),
    [
        'AAA',
        'BCD',
        'EFE'
    ],
    {
        F: 'roll_mod:treated_planks',
        A: 'minecraft:glass',
        C: 'modern_industrialization:electrum_plate',
        D: 'modern_industrialization:steel_rod',
        B: 'modern_industrialization:redstone_alloy_rod',
        E: 'modern_industrialization:redstone_alloy_bolt'
    }
)

event.shaped(
    Item.of('modern_industrialization:analog_circuit'),
    [
        'AAA',
        'BCB',
    ],
    {
        A: 'roll_mod:redstone_tube',
        B: 'modern_industrialization:resistor',
        C: 'modern_industrialization:analog_circuit_board'
    }
)

event.shaped(
    Item.of('roll_mod:amethyst_oscillator'),
    [
        'ABA',
        'BCB',
        'ADA'
    ],
    {
        C: 'minecraft:amethyst_cluster',
        D: 'modern_industrialization:analog_circuit',
        B: 'modern_industrialization:electrum_wire',
        A: 'modern_industrialization:steel_plate'
    }
)

event.shaped(
    Item.of('modern_industrialization:laser_engraver'),
    [
        'ABA',
        'CDC',
        'EFE'
    ],
    {
        F: 'modern_industrialization:large_motor',
        A: 'roll_mod:energium_laser',
        E: 'modern_industrialization:digital_circuit',
        C: 'modern_industrialization:robot_arm',
        D: 'modern_industrialization:advanced_machine_hull',
        B: 'roll_mod:mirror'
    }
)

event.shaped(
    Item.of('ae2:spatial_io_port'),
    [
        'ABA',
        'CDE',
        'FFF'
    ],
    {
        F: 'ae2:spatial_pylon',
        E: 'ae2:annihilation_core',
        D: 'ae2:io_port',
        C: 'ae2:formation_core',
        B: 'megacells:accumulation_processor',
        A: 'modern_industrialization:osmiridium_plate'
    }
)

event.shaped(
    Item.of('roll_mod:golden_potato'),
    [
        'AAA',
        'ABA',
        'AAA'
    ],
    {
        A: 'minecraft:gold_nugget',
        B: 'minecraft:potato'
    }
)

event.shaped(
    Item.of('immersive_aircraft:propeller'),
    [
        'AA ',
        ' B ',
        ' AA'
    ],
    {
        B: 'modern_industrialization:steel_rod',
        A: 'modern_industrialization:steel_plate'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:backpack'),
    [
        'ABA',
        'ACA',
        'BBB'
    ],
    {
        B: 'minecraft:leather',
        C: 'sophisticatedstorage:iron_chest',
        A: 'minecraft:string'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:magnet_upgrade'),
    [
        'ABA',
        'ACA',
        'DDD'
    ],
    {
        B: 'modern_industrialization:steel_rod_magnetic',
        A: 'roll_mod:raw_magnetite',
        C: 'sophisticatedbackpacks:upgrade_base',
        D: 'modern_industrialization:steel_plate'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:advanced_magnet_upgrade'),
    [
        'AAA',
        'ABA',
        'CCC'
    ],
    {
        A: 'modern_industrialization:stainless_steel_rod_magnetic',
        B: 'sophisticatedbackpacks:magnet_upgrade',
        C: 'modern_industrialization:stainless_steel_plate'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:stack_upgrade_starter_tier'),
    [
        'AAA',
        'ABA',
        'AAA'
    ],
    {
        A: 'modern_industrialization:bronze_block',
        B: 'sophisticatedbackpacks:upgrade_base'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:upgrade_base'),
    [
        'ABA',
        'BCB',
        'ABA'
    ],
    {
        C: 'minecraft:leather',
        A: 'modern_industrialization:bronze_plate',
        B: 'roll_mod:treated_plate'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:stack_upgrade_tier_2'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        A: 'modern_industrialization:aluminum_block',
        C: 'sophisticatedbackpacks:stack_upgrade_tier_1',
        D: 'roll_mod:treated_plate',
        B: 'modern_industrialization:electronic_circuit'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:stack_upgrade_tier_1'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        A: 'modern_industrialization:steel_block',
        C: 'modern_industrialization:analog_circuit',
        D: 'roll_mod:treated_plate',
        B: 'sophisticatedbackpacks:stack_upgrade_starter_tier'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:stack_upgrade_tier_4'),
    [
        'AAA',
        'BCB',
        'AAA'
    ],
    {
        A: 'modern_industrialization:titanium_block',
        B: 'sophisticatedbackpacks:stack_upgrade_tier_3',
        C: 'roll_mod:treated_plate'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:stack_upgrade_tier_3'),
    [
        'AAA',
        'BCB',
        'AAA'
    ],
    {
        B: 'sophisticatedbackpacks:stack_upgrade_tier_2',
        C: 'roll_mod:treated_plate',
        A: 'modern_industrialization:stainless_steel_block'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:stack_upgrade_omega_tier'),
    [
        'ABA',
        'BCB',
        'ABA'
    ],
    {
        B: 'sophisticatedbackpacks:stack_upgrade_tier_4',
        A: 'modern_industrialization:processing_unit',
        C: 'roll_mod:treated_plate'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:pump_upgrade'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        C: 'minecraft:bucket',
        B: 'modern_industrialization:bronze_water_pump',
        D: 'sophisticatedbackpacks:upgrade_base',
        A: 'modern_industrialization:rubber_sheet'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:everlasting_upgrade'),
    [
        'ABA',
        'BCB',
        'ABA'
    ],
    {
        B: 'roll_mod:nether_star_plate',
        C: 'sophisticatedbackpacks:upgrade_base',
        A: 'roll_mod:quantum_star'
    }
)

event.remove({ output: 'sophisticatedstorage:stack_upgrade_tier_1' })

event.shaped(
    Item.of('sophisticatedstorage:magnet_upgrade'),
    [
        'ABA',
        'ACA',
        'DDD'
    ],
    {
        B: 'modern_industrialization:steel_rod_magnetic',
        A: 'roll_mod:raw_magnetite',
        C: 'sophisticatedstorage:upgrade_base',
        D: 'modern_industrialization:steel_plate'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:advanced_magnet_upgrade'),
    [
        'AAA',
        'ABA',
        'CCC'
    ],
    {
        A: 'modern_industrialization:stainless_steel_rod_magnetic',
        B: 'sophisticatedstorage:magnet_upgrade',
        C: 'modern_industrialization:stainless_steel_plate'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:stack_upgrade_tier_1_plus'),
    [
        'AAA',
        'ABA',
        'AAA'
    ],
    {
        A: 'modern_industrialization:bronze_block',
        B: 'sophisticatedstorage:upgrade_base'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:upgrade_base'),
    [
        'ABA',
        'BCB',
        'ABA'
    ],
    {
        C: '#minecraft:logs',
        A: 'modern_industrialization:bronze_plate',
        B: 'roll_mod:treated_plate'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:stack_upgrade_tier_2'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        A: 'modern_industrialization:aluminum_block',
        C: 'sophisticatedstorage:stack_upgrade_tier_1',
        D: 'roll_mod:treated_plate',
        B: 'modern_industrialization:electronic_circuit'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:stack_upgrade_tier_1_plus'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        A: 'modern_industrialization:steel_block',
        C: 'modern_industrialization:analog_circuit',
        D: 'roll_mod:treated_plate',
        B: 'sophisticatedstorage:stack_upgrade_tier_1_plus'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:stack_upgrade_tier_4'),
    [
        'AAA',
        'BCB',
        'AAA'
    ],
    {
        A: 'modern_industrialization:titanium_block',
        B: 'sophisticatedstorage:stack_upgrade_tier_3',
        C: 'roll_mod:treated_plate'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:stack_upgrade_tier_3'),
    [
        'AAA',
        'BCB',
        'AAA'
    ],
    {
        B: 'sophisticatedstorage:stack_upgrade_tier_2',
        C: 'roll_mod:treated_plate',
        A: 'modern_industrialization:stainless_steel_block'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:stack_upgrade_omega_tier'),
    [
        'ABA',
        'BCB',
        'ABA'
    ],
    {
        B: 'sophisticatedstorage:stack_upgrade_tier_4',
        A: 'modern_industrialization:processing_unit',
        C: 'roll_mod:treated_plate'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:pump_upgrade'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        C: 'minecraft:bucket',
        B: 'modern_industrialization:bronze_water_pump',
        D: 'sophisticatedstorage:upgrade_base',
        A: 'modern_industrialization:rubber_sheet'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:everlasting_upgrade'),
    [
        'ABA',
        'BCB',
        'ABA'
    ],
    {
        B: 'roll_mod:nether_star_plate',
        C: 'sophisticatedstorage:upgrade_base',
        A: 'roll_mod:quantum_star'
    }
)

event.shaped(
    Item.of('toms_storage:polymorphic_item_filter'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        C: 'modern_industrialization:item_pipe',
        A: 'modern_industrialization:diamond_dust',
        B: 'modern_industrialization:configurable_chest',
        D: 'toms_storage:item_filter'
    }
)

event.shaped(
    Item.of('toms_storage:item_filter'),
    [
        'ABA',
        'BCB',
        'ABA'
    ],
    {
        B: 'modern_industrialization:item_pipe',
        C: 'minecraft:hopper',
        A: 'modern_industrialization:iron_dust'
    }
)

event.shaped(
    Item.of('toms_storage:tag_item_filter'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        B: 'modern_industrialization:item_pipe',
        A: 'modern_industrialization:gold_dust',
        C: 'modern_industrialization:configurable_chest',
        D: 'toms_storage:item_filter'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:feeding_upgrade'),
    [
        'ABA',
        'CDE',
        'FGF'
    ],
    {
        F: 'roll_mod:advanced_robot_arm',
        G: 'modern_industrialization:digital_circuit',
        C: 'sophisticatedstorage:advanced_alchemy_upgrade',
        D: 'sophisticatedstorage:upgrade_base',
        A: 'minecraft:enchanted_golden_apple',
        E: 'sophisticatedstorage:advanced_refill_upgrade',
        B: 'extended_industrialization:robot_auto_feeder'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:advanced_feeding_upgrade'),
    [
        'ABC',
        'DED',
        'FGH'
    ],
    {
        A: 'tide:bedrock_bug',
        H: 'roll_mod:very_nutritious_candy',
        C: 'roll_mod:sulfur_jam',
        D: 'modern_industrialization:processing_unit',
        E: 'sophisticatedstorage:feeding_upgrade',
        F: 'stellaris:moon_fruit',
        B: 'yet_another_industrialization:configurable_mixed_storage',
        G: 'modern_industrialization:iridium_plate'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:filter_upgrade'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        A: 'modern_industrialization:item_pipe',
        B: 'minecraft:hopper',
        D: 'sophisticatedstorage:upgrade_base',
        C: 'toms_storage:item_filter'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:compacting_upgrade'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        C: 'minecraft:crafting_table',
        A: 'modern_industrialization:item_pipe',
        B: 'minecraft:hopper',
        D: 'sophisticatedstorage:upgrade_base'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:advanced_filter_upgrade'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        A: 'modern_industrialization:item_pipe',
        C: 'modern_industrialization:configurable_chest',
        D: 'sophisticatedstorage:filter_upgrade',
        B: 'toms_storage:item_filter'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:advanced_compacting_upgrade'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        C: 'minecraft:crafter',
        A: 'modern_industrialization:item_pipe',
        B: 'modern_industrialization:configurable_chest',
        D: 'sophisticatedstorage:compacting_upgrade'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:deposit_upgrade'),
    [
        'AAA',
        'BCB',
        'DDD'
    ],
    {
        A: 'modern_industrialization:item_pipe',
        D: 'minecraft:hopper',
        B: 'roll_mod:treated_plate',
        C: 'sophisticatedstorage:upgrade_base'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:restock_upgrade'),
    [
        'AAA',
        'BCB',
        'DDD'
    ],
    {
        D: 'modern_industrialization:item_pipe',
        A: 'minecraft:hopper',
        B: 'roll_mod:treated_plate',
        C: 'sophisticatedstorage:upgrade_base'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:advanced_restock_upgrade'),
    [
        'AAA',
        'BCB',
        'DDD'
    ],
    {
        C: 'sophisticatedstorage:restock_upgrade',
        D: 'modern_industrialization:item_pipe',
        A: 'modern_industrialization:configurable_chest',
        B: 'roll_mod:treated_plate'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:pickup_upgrade'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        A: 'modern_industrialization:item_pipe',
        B: 'minecraft:hopper',
        C: 'modern_industrialization:robot_arm',
        D: 'sophisticatedstorage:upgrade_base'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:advanced_pickup_upgrade'),
    [
        'ABA',
        'BCB',
        'ABA'
    ],
    {
        A: 'modern_industrialization:item_pipe',
        C: 'sophisticatedstorage:pickup_upgrade',
        B: 'modern_industrialization:configurable_chest'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:advanced_pump_upgrade'),
    [
        'ABA',
        'BCB',
        'ADA'
    ],
    {
        B: 'modern_industrialization:fluid_pipe',
        C: 'sophisticatedstorage:pump_upgrade',
        D: 'modern_industrialization:steel_water_pump',
        A: 'modern_industrialization:rubber_sheet'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:xp_pump_upgrade'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        C: 'minecraft:ender_eye',
        D: 'sophisticatedstorage:advanced_pump_upgrade',
        A: 'modern_industrialization:pump',
        B: 'minecraft:experience_bottle'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:smelting_upgrade'),
    [
        'ABA',
        'BCB',
        'ADA'
    ],
    {
        A: 'modern_industrialization:bronze_plate',
        B: 'roll_mod:treated_plate',
        C: 'sophisticatedstorage:upgrade_base',
        D: 'minecraft:furnace'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:void_upgrade'),
    [
        'ABA',
        'ACA',
        'ADA'
    ],
    {
        A: 'modern_industrialization:item_pipe',
        B: 'minecraft:hopper',
        C: 'sophisticatedstorage:upgrade_base',
        D: 'modern_industrialization:trash_can'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:auto_smelting_upgrade'),
    [
        'ABA',
        'CDC',
        'AEA'
    ],
    {
        C: 'modern_industrialization:item_pipe',
        B: 'modern_industrialization:configurable_chest',
        E: 'roll_mod:treated_plate',
        D: 'sophisticatedstorage:smelting_upgrade',
        A: 'modern_industrialization:steel_plate'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:advanced_void_upgrade'),
    [
        'ABA',
        'ACA',
        'ADA'
    ],
    {
        A: 'modern_industrialization:item_pipe',
        C: 'sophisticatedstorage:void_upgrade',
        B: 'modern_industrialization:configurable_chest',
        D: 'modern_industrialization:trash_can'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:blasting_upgrade'),
    [
        'ABA',
        'BCB',
        'ADA'
    ],
    {
        A: 'modern_industrialization:bronze_plate',
        B: 'roll_mod:treated_plate',
        C: 'sophisticatedstorage:upgrade_base',
        D: 'minecraft:blast_furnace'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:smoking_upgrade'),
    [
        'ABA',
        'BCB',
        'ADA'
    ],
    {
        A: 'modern_industrialization:bronze_plate',
        B: 'roll_mod:treated_plate',
        C: 'sophisticatedstorage:upgrade_base',
        D: 'minecraft:smoker'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:auto_blasting_upgrade'),
    [
        'ABA',
        'CDC',
        'AEA'
    ],
    {
        D: 'sophisticatedstorage:blasting_upgrade',
        C: 'modern_industrialization:item_pipe',
        B: 'modern_industrialization:configurable_chest',
        E: 'roll_mod:treated_plate',
        A: 'modern_industrialization:steel_plate'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:alchemy_upgrade'),
    [
        'ABA',
        'CDC',
        'AEA'
    ],
    {
        E: 'extended_industrialization:steel_brewery',
        A: 'modern_industrialization:bronze_plate',
        C: 'roll_mod:treated_plate',
        D: 'sophisticatedstorage:upgrade_base',
        B: 'minecraft:glass_bottle'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:jukebox_upgrade'),
    [
        'ABA',
        'CDC',
        'AEA'
    ],
    {
        B: 'minecraft:chest',
        A: 'modern_industrialization:bronze_plate',
        C: 'roll_mod:treated_plate',
        D: 'sophisticatedstorage:upgrade_base',
        E: 'minecraft:jukebox'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:advanced_alchemy_upgrade'),
    [
        'ABA',
        'CDC',
        'AEA'
    ],
    {
        E: 'modern_industrialization:analog_circuit',
        B: 'modern_industrialization:robot_arm',
        D: 'sophisticatedstorage:alchemy_upgrade',
        C: 'roll_mod:treated_plate',
        A: 'modern_industrialization:steel_plate'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:advanced_jukebox_upgrade'),
    [
        'ABA',
        'CDC',
        'AEA'
    ],
    {
        E: 'modern_industrialization:analog_circuit',
        B: 'sophisticatedstorage:iron_chest',
        D: 'sophisticatedstorage:jukebox_upgrade',
        C: 'roll_mod:treated_plate',
        A: 'modern_industrialization:steel_plate'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:stonecutter_upgrade'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        A: 'modern_industrialization:bronze_plate',
        C: 'roll_mod:treated_plate',
        D: 'sophisticatedstorage:upgrade_base',
        B: 'minecraft:stonecutter'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:crafting_upgrade'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        B: 'minecraft:crafter',
        A: 'modern_industrialization:bronze_plate',
        C: 'roll_mod:treated_plate',
        D: 'sophisticatedstorage:upgrade_base'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:anvil_upgrade'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        B: 'minecraft:anvil',
        A: 'modern_industrialization:bronze_plate',
        C: 'roll_mod:treated_plate',
        D: 'sophisticatedstorage:upgrade_base'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:tank_upgrade'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        A: 'modern_industrialization:bronze_plate',
        D: 'sophisticatedstorage:upgrade_base',
        C: 'modern_industrialization:rubber_sheet',
        B: 'modern_industrialization:steel_tank'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:smithing_upgrade'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        B: 'minecraft:smithing_table',
        A: 'modern_industrialization:bronze_plate',
        C: 'roll_mod:treated_plate',
        D: 'sophisticatedstorage:upgrade_base'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:stack_downgrade_tier_2'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        A: 'modern_industrialization:bronze_plate',
        D: 'sophisticatedstorage:stack_downgrade_tier_1',
        B: 'modern_industrialization:creosote_bucket',
        C: 'roll_mod:treated_plate'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:stack_downgrade_tier_1'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        A: 'modern_industrialization:bronze_plate',
        B: 'modern_industrialization:creosote_bucket',
        C: 'roll_mod:treated_plate',
        D: 'sophisticatedstorage:upgrade_base'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:stack_downgrade_tier_3'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        D: 'sophisticatedstorage:stack_downgrade_tier_2',
        A: 'modern_industrialization:bronze_plate',
        B: 'modern_industrialization:creosote_bucket',
        C: 'roll_mod:treated_plate'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:refill_upgrade'),
    [
        'ABA',
        'CDC',
        'AEA'
    ],
    {
        B: 'minecraft:hopper',
        A: 'modern_industrialization:bronze_plate',
        E: 'modern_industrialization:robot_arm',
        C: 'roll_mod:treated_plate',
        D: 'sophisticatedstorage:upgrade_base'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:advanced_refill_upgrade'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        B: 'modern_industrialization:analog_circuit',
        D: 'sophisticatedstorage:refill_upgrade',
        C: 'roll_mod:treated_plate',
        A: 'modern_industrialization:steel_plate'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:hopper_upgrade'),
    [
        ' A ',
        ' B ',
        ' C '
    ],
    {
        A: 'minecraft:hopper',
        C: 'modern_industrialization:configurable_chest',
        B: 'sophisticatedstorage:upgrade_base'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:advanced_hopper_upgrade'),
    [
        ' A ',
        'DBD',
        ' C '
    ],
    {
        A: 'minecraft:hopper',
        C: 'extended_industrialization:large_configurable_chest',
        B: 'sophisticatedstorage:upgrade_base',
		D: 'roll_mod:advanced_robot_arm'
    }
)

event.shaped(
    Item.of('sophisticatedstorage:compression_upgrade'),
    [
        'ABA',
        'CDE',
        'AFA'
    ],
    {
        F: 'minecraft:hopper',
        C: 'modern_industrialization:packer_double_ingot_template',
        E: 'modern_industrialization:packer_block_template',
        D: 'sophisticatedstorage:upgrade_base',
        A: 'modern_industrialization:steel_plate',
        B: 'minecraft:piston'
    }
)


// --- sophisticated storage tier upgrades ---

ServerEvents.recipes(event => {
    // Remove all existing tier upgrade recipes to avoid conflicts
    event.remove({ id: /sophisticatedstorage:.*_tier_upgrade/ });

    // Important: keep this specific removal to prevent duplicate recipe issues
    event.remove({ id: 'sophisticatedstorage:basic_to_iron_tier_from_basic_to_copper_tier' })

    // Material definitions for each tier
    // Each material provides a plate and a rod for crafting
    const mats = {
        bronze:    { p: "modern_industrialization:bronze_plate", r: "modern_industrialization:bronze_rod" },
        steel:     { p: "modern_industrialization:steel_plate", r: "modern_industrialization:steel_rod" },
        aluminum:  { p: "modern_industrialization:aluminum_plate", r: "modern_industrialization:aluminum_rod" },
        stainless: { p: "modern_industrialization:stainless_steel_plate", r: "modern_industrialization:stainless_steel_rod" },
        titanium:  { p: "modern_industrialization:titanium_plate", r: "modern_industrialization:titanium_rod" }
    };

    // Helper function to create a shaped tier upgrade recipe
    // Pattern: plates in corners, rods on edges, input upgrade in center
    const addUpgrade = (input, output, matKey) => {
        event.shaped(`sophisticatedstorage:${output}_tier_upgrade`, ["PRP", "RSR", "PRP"], {
            P: mats[matKey].p,  // Plate material
            R: mats[matKey].r,  // Rod material
            S: input             // Source upgrade (what we're upgrading from)
        });
    };

    // ----- Basic tier upgrade chain -----
    // Basic -> Copper -> Iron -> Gold -> Diamond -> Netherite
    addUpgrade("sophisticatedstorage:basic_tier_upgrade", "basic_to_copper", "bronze");
    addUpgrade("sophisticatedstorage:basic_to_copper_tier_upgrade", "basic_to_iron", "steel");
    addUpgrade("sophisticatedstorage:basic_to_iron_tier_upgrade", "basic_to_gold", "aluminum");
    addUpgrade("sophisticatedstorage:basic_to_gold_tier_upgrade", "basic_to_diamond", "stainless");
    addUpgrade("sophisticatedstorage:basic_to_diamond_tier_upgrade", "basic_to_netherite", "titanium");

    // ----- Copper tier upgrade chain -----
    // Upgrade Base -> Copper -> Iron -> Gold -> Diamond -> Netherite
    addUpgrade("sophisticatedstorage:upgrade_base", "copper_to_iron", "steel");
    addUpgrade("sophisticatedstorage:copper_to_iron_tier_upgrade", "copper_to_gold", "aluminum");
    addUpgrade("sophisticatedstorage:copper_to_gold_tier_upgrade", "copper_to_diamond", "stainless");
    addUpgrade("sophisticatedstorage:copper_to_diamond_tier_upgrade", "copper_to_netherite", "titanium");

    // ----- Iron tier upgrade chain -----
    // Upgrade Base -> Iron -> Gold -> Diamond -> Netherite
    addUpgrade("sophisticatedstorage:upgrade_base", "iron_to_gold", "aluminum");
    addUpgrade("sophisticatedstorage:iron_to_gold_tier_upgrade", "iron_to_diamond", "stainless");
    addUpgrade("sophisticatedstorage:iron_to_diamond_tier_upgrade", "iron_to_netherite", "titanium");

    // ----- Gold tier upgrade chain -----
    // Upgrade Base -> Gold -> Diamond -> Netherite
    addUpgrade("sophisticatedstorage:upgrade_base", "gold_to_diamond", "stainless");
    addUpgrade("sophisticatedstorage:gold_to_diamond_tier_upgrade", "gold_to_netherite", "titanium");

    // ----- Diamond tier upgrade chain -----
    // Upgrade Base -> Diamond -> Netherite
    addUpgrade("sophisticatedstorage:upgrade_base", "diamond_to_netherite", "titanium");
});

// --- sophisticated storage tier upgrades ---

event.shaped(
    Item.of('toms_storage:polymorphic_item_filter'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        C: 'modern_industrialization:item_pipe',
        A: 'modern_industrialization:diamond_dust',
        B: 'modern_industrialization:configurable_chest',
        D: 'toms_storage:item_filter'
    }
)

event.shaped(
    Item.of('toms_storage:item_filter'),
    [
        'ABA',
        'BCB',
        'ABA'
    ],
    {
        B: 'modern_industrialization:item_pipe',
        C: 'minecraft:hopper',
        A: 'modern_industrialization:iron_dust'
    }
)

event.shaped(
    Item.of('toms_storage:tag_item_filter'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        B: 'modern_industrialization:item_pipe',
        A: 'modern_industrialization:gold_dust',
        C: 'modern_industrialization:configurable_chest',
        D: 'toms_storage:item_filter'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:feeding_upgrade'),
    [
        'ABA',
        'CDE',
        'FGF'
    ],
    {
        F: 'roll_mod:advanced_robot_arm',
        G: 'modern_industrialization:digital_circuit',
        C: 'sophisticatedbackpacks:advanced_alchemy_upgrade',
        D: 'sophisticatedbackpacks:upgrade_base',
        A: 'minecraft:enchanted_golden_apple',
        E: 'sophisticatedbackpacks:advanced_refill_upgrade',
        B: 'extended_industrialization:robot_auto_feeder'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:advanced_feeding_upgrade'),
    [
        'ABC',
        'DED',
        'FGH'
    ],
    {
        A: 'tide:bedrock_bug',
        H: 'roll_mod:very_nutritious_candy',
        C: 'roll_mod:sulfur_jam',
        D: 'modern_industrialization:processing_unit',
        E: 'sophisticatedbackpacks:feeding_upgrade',
        F: 'stellaris:moon_fruit',
        B: 'yet_another_industrialization:configurable_mixed_storage',
        G: 'modern_industrialization:iridium_plate'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:filter_upgrade'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        A: 'modern_industrialization:item_pipe',
        B: 'minecraft:hopper',
        D: 'sophisticatedbackpacks:upgrade_base',
        C: 'toms_storage:item_filter'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:compacting_upgrade'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        C: 'minecraft:crafting_table',
        A: 'modern_industrialization:item_pipe',
        B: 'minecraft:hopper',
        D: 'sophisticatedbackpacks:upgrade_base'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:advanced_filter_upgrade'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        A: 'modern_industrialization:item_pipe',
        C: 'modern_industrialization:configurable_chest',
        D: 'sophisticatedbackpacks:filter_upgrade',
        B: 'toms_storage:item_filter'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:advanced_compacting_upgrade'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        C: 'minecraft:crafter',
        A: 'modern_industrialization:item_pipe',
        B: 'modern_industrialization:configurable_chest',
        D: 'sophisticatedbackpacks:compacting_upgrade'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:deposit_upgrade'),
    [
        'AAA',
        'BCB',
        'DDD'
    ],
    {
        A: 'modern_industrialization:item_pipe',
        D: 'minecraft:hopper',
        B: 'roll_mod:treated_plate',
        C: 'sophisticatedbackpacks:upgrade_base'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:restock_upgrade'),
    [
        'AAA',
        'BCB',
        'DDD'
    ],
    {
        D: 'modern_industrialization:item_pipe',
        A: 'minecraft:hopper',
        B: 'roll_mod:treated_plate',
        C: 'sophisticatedbackpacks:upgrade_base'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:advanced_restock_upgrade'),
    [
        'AAA',
        'BCB',
        'DDD'
    ],
    {
        C: 'sophisticatedbackpacks:restock_upgrade',
        D: 'modern_industrialization:item_pipe',
        A: 'modern_industrialization:configurable_chest',
        B: 'roll_mod:treated_plate'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:pickup_upgrade'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        A: 'modern_industrialization:item_pipe',
        B: 'minecraft:hopper',
        C: 'modern_industrialization:robot_arm',
        D: 'sophisticatedbackpacks:upgrade_base'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:advanced_pickup_upgrade'),
    [
        'ABA',
        'BCB',
        'ABA'
    ],
    {
        A: 'modern_industrialization:item_pipe',
        C: 'sophisticatedbackpacks:pickup_upgrade',
        B: 'modern_industrialization:configurable_chest'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:advanced_pump_upgrade'),
    [
        'ABA',
        'BCB',
        'ADA'
    ],
    {
        B: 'modern_industrialization:fluid_pipe',
        C: 'sophisticatedbackpacks:pump_upgrade',
        D: 'modern_industrialization:steel_water_pump',
        A: 'modern_industrialization:rubber_sheet'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:xp_pump_upgrade'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        C: 'minecraft:ender_eye',
        D: 'sophisticatedbackpacks:advanced_pump_upgrade',
        A: 'modern_industrialization:pump',
        B: 'minecraft:experience_bottle'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:smelting_upgrade'),
    [
        'ABA',
        'BCB',
        'ADA'
    ],
    {
        A: 'modern_industrialization:bronze_plate',
        B: 'roll_mod:treated_plate',
        C: 'sophisticatedbackpacks:upgrade_base',
        D: 'minecraft:furnace'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:void_upgrade'),
    [
        'ABA',
        'ACA',
        'ADA'
    ],
    {
        A: 'modern_industrialization:item_pipe',
        B: 'minecraft:hopper',
        C: 'sophisticatedbackpacks:upgrade_base',
        D: 'modern_industrialization:trash_can'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:auto_smelting_upgrade'),
    [
        'ABA',
        'CDC',
        'AEA'
    ],
    {
        C: 'modern_industrialization:item_pipe',
        B: 'modern_industrialization:configurable_chest',
        E: 'roll_mod:treated_plate',
        D: 'sophisticatedbackpacks:smelting_upgrade',
        A: 'modern_industrialization:steel_plate'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:advanced_void_upgrade'),
    [
        'ABA',
        'ACA',
        'ADA'
    ],
    {
        A: 'modern_industrialization:item_pipe',
        C: 'sophisticatedbackpacks:void_upgrade',
        B: 'modern_industrialization:configurable_chest',
        D: 'modern_industrialization:trash_can'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:blasting_upgrade'),
    [
        'ABA',
        'BCB',
        'ADA'
    ],
    {
        A: 'modern_industrialization:bronze_plate',
        B: 'roll_mod:treated_plate',
        C: 'sophisticatedbackpacks:upgrade_base',
        D: 'minecraft:blast_furnace'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:smoking_upgrade'),
    [
        'ABA',
        'BCB',
        'ADA'
    ],
    {
        A: 'modern_industrialization:bronze_plate',
        B: 'roll_mod:treated_plate',
        C: 'sophisticatedbackpacks:upgrade_base',
        D: 'minecraft:smoker'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:auto_blasting_upgrade'),
    [
        'ABA',
        'CDC',
        'AEA'
    ],
    {
        D: 'sophisticatedbackpacks:blasting_upgrade',
        C: 'modern_industrialization:item_pipe',
        B: 'modern_industrialization:configurable_chest',
        E: 'roll_mod:treated_plate',
        A: 'modern_industrialization:steel_plate'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:auto_blasting_upgrade'),
    [
        'ABA',
        'CDC',
        'AEA'
    ],
    {
        D: 'sophisticatedbackpacks:blasting_upgrade',
        C: 'modern_industrialization:item_pipe',
        B: 'modern_industrialization:configurable_chest',
        E: 'roll_mod:treated_plate',
        A: 'modern_industrialization:steel_plate'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:alchemy_upgrade'),
    [
        'ABA',
        'CDC',
        'AEA'
    ],
    {
        E: 'extended_industrialization:steel_brewery',
        A: 'modern_industrialization:bronze_plate',
        C: 'roll_mod:treated_plate',
        D: 'sophisticatedbackpacks:upgrade_base',
        B: 'minecraft:glass_bottle'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:jukebox_upgrade'),
    [
        'ABA',
        'CDC',
        'AEA'
    ],
    {
        B: 'minecraft:chest',
        A: 'modern_industrialization:bronze_plate',
        C: 'roll_mod:treated_plate',
        D: 'sophisticatedbackpacks:upgrade_base',
        E: 'minecraft:jukebox'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:advanced_alchemy_upgrade'),
    [
        'ABA',
        'CDC',
        'AEA'
    ],
    {
        E: 'modern_industrialization:analog_circuit',
        B: 'modern_industrialization:robot_arm',
        D: 'sophisticatedbackpacks:alchemy_upgrade',
        C: 'roll_mod:treated_plate',
        A: 'modern_industrialization:steel_plate'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:advanced_jukebox_upgrade'),
    [
        'ABA',
        'CDC',
        'AEA'
    ],
    {
        E: 'modern_industrialization:analog_circuit',
        B: 'sophisticatedstorage:iron_chest',
        D: 'sophisticatedbackpacks:jukebox_upgrade',
        C: 'roll_mod:treated_plate',
        A: 'modern_industrialization:steel_plate'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:stonecutter_upgrade'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        A: 'modern_industrialization:bronze_plate',
        C: 'roll_mod:treated_plate',
        D: 'sophisticatedbackpacks:upgrade_base',
        B: 'minecraft:stonecutter'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:crafting_upgrade'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        B: 'minecraft:crafter',
        A: 'modern_industrialization:bronze_plate',
        C: 'roll_mod:treated_plate',
        D: 'sophisticatedbackpacks:upgrade_base'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:anvil_upgrade'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        B: 'minecraft:anvil',
        A: 'modern_industrialization:bronze_plate',
        C: 'roll_mod:treated_plate',
        D: 'sophisticatedbackpacks:upgrade_base'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:tank_upgrade'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        A: 'modern_industrialization:bronze_plate',
        D: 'sophisticatedbackpacks:upgrade_base',
        C: 'modern_industrialization:rubber_sheet',
        B: 'modern_industrialization:steel_tank'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:smithing_upgrade'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        B: 'minecraft:smithing_table',
        A: 'modern_industrialization:bronze_plate',
        C: 'roll_mod:treated_plate',
        D: 'sophisticatedbackpacks:upgrade_base'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:stack_downgrade_tier_2'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        A: 'modern_industrialization:bronze_plate',
        D: 'sophisticatedbackpacks:stack_downgrade_tier_1',
        B: 'modern_industrialization:creosote_bucket',
        C: 'roll_mod:treated_plate'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:stack_downgrade_tier_1'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        A: 'modern_industrialization:bronze_plate',
        B: 'modern_industrialization:creosote_bucket',
        C: 'roll_mod:treated_plate',
        D: 'sophisticatedbackpacks:upgrade_base'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:stack_downgrade_tier_3'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        D: 'sophisticatedbackpacks:stack_downgrade_tier_2',
        A: 'modern_industrialization:bronze_plate',
        B: 'modern_industrialization:creosote_bucket',
        C: 'roll_mod:treated_plate'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:refill_upgrade'),
    [
        'ABA',
        'CDC',
        'AEA'
    ],
    {
        B: 'minecraft:hopper',
        A: 'modern_industrialization:bronze_plate',
        E: 'modern_industrialization:robot_arm',
        C: 'roll_mod:treated_plate',
        D: 'sophisticatedbackpacks:upgrade_base'
    }
)

event.shaped(
    Item.of('sophisticatedbackpacks:advanced_refill_upgrade'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        B: 'modern_industrialization:analog_circuit',
        D: 'sophisticatedbackpacks:refill_upgrade',
        C: 'roll_mod:treated_plate',
        A: 'modern_industrialization:steel_plate'
    }
)

event.shaped(
    Item.of('toms_storage:basic_inventory_hopper', 2),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        C: 'modern_industrialization:bronze_gear',
        B: 'modern_industrialization:item_pipe',
        D: 'minecraft:hopper',
        A: 'roll_mod:treated_plate'
    }
)

event.shaped(
    Item.of('toms_storage:level_emitter', 2),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        B: 'modern_industrialization:analog_circuit',
        D: 'minecraft:redstone_torch',
        C: 'modern_industrialization:bronze_plate',
        A: 'roll_mod:treated_plate'
    }
)

event.shaped(
    Item.of('roll_mod:rocket_controller'),
    [
        'ABA',
        'CDC',
    ],
    {
        A: 'modern_industrialization:netherite_large_plate',
        D: 'roll_mod:research_rocket_controller',
        B: 'modern_industrialization:tungsten_large_plate',
        C: 'modern_industrialization:turbo_machine_hull'
    }
)

event.shaped(
    Item.of('modern_industrialization:incoloy_casing'),
    [
        'ABA',
        'BCB',
        'ABA'
    ],
    {
        A: 'modern_industrialization:chrome_vanadium_steel_large_plate',
        B: 'modern_industrialization:incoloy_large_plate',
        C: 'modern_industrialization:titanium_gear'
    }
)

event.shaped(
    Item.of('modern_industrialization:incoloy_machine_casing_pipe'),
    [
        'ABA',
        'CDC',
        'ABA'
    ],
    {
        A: 'modern_industrialization:incoloy_gear',
        D: 'modern_industrialization:incoloy_casing',
        B: 'modern_industrialization:incoloy_rotor',
        C: 'modern_industrialization:large_advanced_motor'
    }
)

event.shaped(
    Item.of('roll_mod:primitive_battery'),
    [
        'AAA',
        'BCD',
        ' E '
    ],
    {
        A: 'modern_industrialization:sulfur_dust',
        B: 'modern_industrialization:copper_plate',
        C: 'minecraft:water_bucket',
        D: 'modern_industrialization:zinc_plate',
        E: 'minecraft:glass'
    }
)


})